import json
from rest_framework import permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from django.contrib.auth import get_user_model
User = get_user_model()


class SignupView(APIView):
    permission_classes = (permissions.AllowAny, )

    def post(self, request, format=None):
        data = self.request.data

        name = data['name']
        email = data['email']
        gender = data['gender']
        dob = data['dob']
        phone = data['phone']
        address = data['address']
        password = data['password']
        confirm_password = data['password2']

        if password == confirm_password:
            if User.objects.filter(email=email).exists():
                return Response({'error': 'Email already exists'})
            else:
                if len(password) < 8:
                    return Response({'errors':
                                     'Password must at least 8 characters.'})
                else:
                    user = User.objects.create_user(
                        email=email, password=password, name=name,
                        gender=gender, dob=dob, phone=phone, address=address)

                    user.save()
                    return Response({'success': 'User created successfully'})
        else:
            return Response({'error': 'Password do not match'})
