/** @format */

import React from "react";
import Home from "./Components/Home/Home";
import Register from "./Components/Account/Register";
import Pdash from "./Components/Patientdash/Pdash";
import Login from "./Components/Account/Login";
import Appointment from "./Components/Appointment/Appointment";
import Profile from "./Components/Account/profile";
import {
  BrowserRouter as Router,
  Route,
  BrowserRouter,
} from "react-router-dom";
import Docdash from "./Components/Doctordash/Docdash";
import Medicalinfo from "./Components/Medication/Medicalinfo";
import { Provider } from "react-redux";
import store from "./Components/Redux/Store";
import "./App.css";
//import QRCode from "./Components/Account/Qrgenerator";

function App() {
  return (
    <BrowserRouter>
      <Provider store={store}>
        <div>
          <Router>
            <Route exact path="/">
              <Home />
            </Route>

            <Route exact path="/Login">
              <Login />
            </Route>
            <Route exact path="/Register">
              <Register />
            </Route>

            <Route exact path="/Pdash">
              <Pdash />
            </Route>
            <Route exact path="/Docdash">
              <Docdash />
            </Route>
            <Route exact path="/appointment">
              <Appointment />
            </Route>
            <Route exact path="/Medicalinfo">
              <Medicalinfo />
            </Route>
            <Route exact path="/profile">
              <Profile />
            </Route>
          </Router>
        </div>
      </Provider>
    </BrowserRouter>
  );
}

export default App;
