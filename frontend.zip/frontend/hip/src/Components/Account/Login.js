/** @format */
import React, { Component } from "react";
import { Link } from "react-router-dom";
import "./login.css";
import "tachyons";
import axiosInstance from "../../axiosapi";
import { withRouter } from "react-router-dom";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import Getloginstate from "../Redux/Actions/Getloginstate";
//import Item from "antd/lib/list/Item";

class Login extends Component {
  constructor() {
    super();
    this.state = { email: "", password: "" };
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  static propTypes = [PropTypes.array];
  changeHandler = (e) => {
    this.setState({ [e.target.name]: e.target.value });
    //console.log(e.target.value);
  };
  async handleSubmit(event) {
    event.preventDefault();
    try {
      let response = await axiosInstance.post("api/token/", {
        email: this.state.email,
        password: this.state.password,
      });
      let token = JSON.stringify(response.data["refresh"]);
      localStorage.setItem("token", token);
      alert(localStorage.getItem("token"));
      console.log(token);
      if (token) {
        this.props.history.push({
          pathname: "/Pdash",
          state: { detail: token },
        });
      }
    } catch (error) {
      throw error;
    }
  }

  componentDidMount() {
    this.props.Getloginstate();
  }
  render() {
    const { email, password } = this.state;

    return (
      <div id="div" className=" tc">
        <form
          onSubmit={this.handleSubmit}
          className="tc dib ba  ma4 bg-light-white "
          style={{
            backgroundColor: "#1D8348",
            marginTop: "100px",
            opacity: "0.6",
            marginBottom: "100px",
          }}
        >
          <div className="login tc ma4 ">
            <img src="/img/login.png" alt=""></img>
          </div>
          <div className="ma4">
            <input
              type="email"
              name="email"
              placeholder="email"
              value={email}
              required
              title="email is Required"
              onChange={this.changeHandler}
            ></input>
          </div>
          <br />
          <div>
            <input
              className="ma4"
              type="password"
              name="password"
              value={password}
              required
              placeholder="password"
              style={{ marginTop: "0px" }}
              onChange={this.changeHandler}
            ></input>
          </div>
          <br />
          <div id="signinup">
            <button type="primary">Sign In</button>
            <Link to="/Register">
              <button type="button">Sign Up</button>
            </Link>
          </div>
          <br />
          <div id="forgotpassword">
            <ul>
              <li>
                <a href="/">Forgot Password</a>
              </li>
            </ul>
          </div>
        </form>
      </div>
    );
  }
}
// const mapStateToProps = (state) => {
//   return { logindata: state.logindata.post };
// };
const mapDispatchToprops = (dispatch) => {
  return { Getloginstate: () => dispatch(Getloginstate(this.state)) };
};
export default connect(mapDispatchToprops, { Getloginstate })(
  withRouter(Login)
);
