/** @format */

import React, { Component } from "react";
import "./login.css";
import "tachyons";
import fetch from "isomorphic-fetch";
import { Link } from "react-router-dom";
class Register extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      email: "",
      gender: "",
      dob: "",
      phone: "",
      address: "",
      password: "",
      confirm_password: "",
    };
  }

  changeHandler = (e) => {
    this.setState({ [e.target.name]: e.target.value });
    console.log(e.target.value);
  };
  submitHandler = (e) => {
    console.log("_____________________________");
    console.log(this.state);
    fetch("http://localhost:8000/register/", {
      method: "POST",
      body: JSON.stringify(this.state),
    })
      .then((response) => {
        console.log("recieved");
        console.log(response);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  render() {
    const {
      name,
      email,
      gender,
      dob,
      phone,
      address,
      password,
      confirm_password,
    } = this.state;
    return (
      <div id="div" className="tc" style={{ backgroundColor: "lightgreen" }}>
        <form
          className="tc dib ba  ma4 bg-light-white  "
          style={{
            backgroundColor: "#1D8348",
            marginTop: "100px",
            opacity: "0.6",
            marginBottom: "100px",
          }}
          onSubmit={this.submitHandler}
        >
          <div className="icon ma4 ">
            <h1>Register</h1>
          </div>

          <div className="mv8">
            <input
              type="text"
              name="name"
              placeholder="Name"
              value={name}
              required
              onChange={this.changeHandler}
            ></input>
          </div>

          <div className="ma4">
            <input
              type="email"
              name="email"
              placeholder="email"
              value={email}
              required
              title="email is Required"
              onChange={this.changeHandler}
            ></input>
          </div>
          <div className="ma4">
            <select value={gender} required onChange={this.changeHandler}>
              <option value="gender">m</option>
              <option value="gender">f</option>
            </select>
          </div>

          <div className="ma4">
            <input
              type="text"
              name="dob"
              placeholder="dob"
              value={dob}
              required
              onChange={this.changeHandler}
            ></input>
          </div>

          <div className="ma4">
            <input
              type="text"
              name="phone"
              placeholder="phone"
              value={phone}
              required
              onChange={this.changeHandler}
            ></input>
          </div>

          <div className="ma4">
            <input
              type="text"
              name="address"
              placeholder="address"
              value={address}
              required
              onChange={this.changeHandler}
            ></input>
          </div>

          <div className="ma4">
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={password}
              required
              pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
              title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"
              onChange={this.changeHandler}
            ></input>
          </div>

          <div className="ma4">
            <input
              type="password"
              name="confirm_password"
              placeholder="confirm_password"
              value={confirm_password}
              required
              pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
              title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"
              onChange={this.changeHandler}
            ></input>
          </div>

          <div id="forgotpassword" style={{ marginBottom: "10px" }}>
            <ul>
              <li>
                <a href="/">Submit</a>
              </li>
            </ul>
          </div>
        </form>
        <Link to="Home"></Link>
      </div>
    );
  }
}
export default Register;
