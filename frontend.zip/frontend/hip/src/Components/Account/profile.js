import React, { Component } from "react";
import { Getaction } from "../Redux/Actions/Getaction";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import "./qr.css";
import { QRious } from "react-qrious";
class Profile extends Component {
  static propTypes = [PropTypes.array];

  componentDidMount() {
    this.props.Getaction();
  }
  // createListItem() {
  //   return this.props.post.map((user) => {
  //     return (
  //       <li key={user.id}>
  //         {user.gender} {user.email}
  //       </li>
  //     );
  //   });
  // }
  render() {
    const arr = [];
    arr.push(localStorage.getItem("token"));

    return (
      <div>
        <ul>
          <li>first name : JOHN</li>
          <br />
          <li>last name : DOE</li>
          <br />
          <li>gender : {this.props.post.gender}</li>
          <br />
          <li>email : {this.props.post.email}</li>
          <br />
          <li>phone : {this.props.post.phone}</li>
          <br />
          <li>cell : {this.props.post.cell}</li>
          <br />
          <li> city : kolkata</li>
          <br />
          <li>rgistered : 2005-03-12T12:14:27.407Z </li>
          <br />
        </ul>
        {/* <div>
          <ul>{this.createListItem()}</ul>
        </div> */}

        <div id="qrcode">
          <QRious value={arr[0]} size={400} level={"m"} />,
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  post: state.post.post,
  items: state.item,
});

export default connect(mapStateToProps, { Getaction })(Profile);
