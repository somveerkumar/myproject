import React, { Component } from "react";
import { GoogleComponent } from "react-google-location";
import axios from "axios";
import ProgressBar from "react-bootstrap/ProgressBar";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
//import Item from 'antd/lib/list/Item'
import "./appointment.css";

// const API_KEY = API_KEY_FROM_GOOGLE

class Appointment extends Component {
  constructor(props) {
    super(props);

    this.state = {
      symptoms: "",
      place: null,
      uploadPercentage: 0,
      // selectedDate: null,
      startDate: null,
      // setSelectedDate: null
    };
  }

  uploadFile = ({ target: { files } }) => {
    console.log(files[0]);
    let data = new FormData();
    data.append("file", files[0]);

    const options = {
      onUploadProgress: (progressEvent) => {
        const { loaded, total } = progressEvent;
        let percent = Math.floor((loaded * 100) / total);
        console.log(`${loaded}kb of ${total}kb | ${percent}%`);

        if (percent < 100) {
          this.setState({ uploadPercentage: percent });
        }
      },
    };

    axios
      .post(
        "https://run.mocky.io/v3/48a9d411-e4d1-4acf-8f92-82ed82128ae3",
        data,
        options
      )
      .then((res) => {
        console.log(res);
        this.setState({ uploadPercentage: 100 }, () => {
          setTimeout(() => {
            this.setState({ uploadPercentage: 0 });
          }, 1000);
        });
      });
  };

  chngSymptom = (event) => {
    this.setState({
      symptoms: event.target.value,
    });
  };

  setSelectedDate = (date) => {
    this.setState({
      startDate: date,
    });
  };

  submit = (event) => {
    event.preventDefault();
    if (
      this.state.symptoms == null ||
      this.state.place == null ||
      this.state.startDate == null
    ) {
      alert(`Enter all fields !`);
    } else
      alert(` Details successfully recorded ! Date requested: ${this.state.startDate} |
    Location: ${this.state.place.currentCoordinates} `);
  };

  save = (event) => {
    event.preventDefault();
    alert(`Kindly review before submitting`);
  };

  render() {
    const { symptoms } = this.state;
    const { uploadPercentage } = this.state;
    // const{selectedDate}=this.state
    // const{setSelectedDate}=this.state

    return (
      <div style={{ height: "400px" }}>
        <header
          className="header bg-light-blue"
          style={{ textAlign: "middle", marginTop: "10px" }}
        >
          {" "}
          MY APPOINTMENT{" "}
        </header>
        <form className="tc dib ba  ma4 bg-light-white ba form">
          <div style={{ marginLeft: "40px" }}>
            <h2>Book an Appointment</h2>
            <input
              type="text"
              value={symptoms}
              placeholder="Enter your symptoms here"
              rows={5}
              cols={5}
              onChange={this.chngSymptom}
            />
            <p></p>
            <DatePicker
              selected={this.state.startDate}
              placeholderText="Preferred appointment date"
              onChange={this.setSelectedDate}
              dateFormat="dd/MM/yyyy"
              minDate={new Date()}
              filterDate={(date) => date.getDay() !== 6 && date.getDay() !== 0}
              showYearDropdown
              scrollableMonthYearDropdown
            />
            <p></p>
            <GoogleComponent
              // apiKey={API_KEY}
              language={"en"}
              country={"country:in|country:us"}
              coordinates={true}
              locationBoxStyle={"custom-style"}
              locationListStyle={"custom-style-list"}
              currentCoordinates={{
                lat: 41.7151377,
                lng: 44.827096,
              }}
              placeholder={"Enter current location"}
              onChange={(e) => {
                this.setState({ place: e });
              }}
            />
            <p></p>
            <h4>
              <b>Upload your report here:</b>
            </h4>
            <input
              type="file"
              className="file-uploader"
              onChange={this.uploadFile}
            />
            {uploadPercentage > 0 && (
              <ProgressBar
                now={uploadPercentage}
                active
                label={`${uploadPercentage}%`}
              />
            )}
            <div>
              <button className="Save" onClick={this.save}>
                Save
              </button>
              <button className="Submit" onClick={this.submit}>
                Submit
              </button>
            </div>
          </div>
        </form>
      </div>
    );
  }
}

export default Appointment;
