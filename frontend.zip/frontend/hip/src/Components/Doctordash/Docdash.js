/** @format */
import React, { Component } from "react";
import "./docdash.css";
import "tachyons";
//import account from "./account"
//import { Link } from "react-router-dom";
//import fetch from "isomorphic-fetch";

class Docdash extends Component {
  render() {
    return (
      <div>
        <body>
          <div id="header">
            <h3>Patient Deshboard</h3>
          </div>

          <div id="main">
            <ul className="sideleft">
              <li>
                <img id="profile" src="/img/profile.png" alt="" />
                <h2> hello</h2>
                <ul className="right-nav">
                  <a class="active" href="/">
                    ACCOUNT
                  </a>
                  <a class="active" href="MEDICAL HISTORY">
                    MEDICAL HISTORY
                  </a>
                  <a class="active" href="MESSAGES">
                    MESSAGES
                  </a>
                  <a class="active" href="MOST RECENT">
                    MOST RECENT
                  </a>
                  <a class="active" href="LANGUAGE">
                    LANGUAGE
                  </a>
                  <a class="active" href="FEEDBACK">
                    FEEDBACK
                  </a>
                  <a class="active" href="SETTING">
                    SETTING
                  </a>
                  <a class="active" href="HELP">
                    HELP
                  </a>
                  <a class="active" href="ABOUT">
                    ABOUT
                  </a>
                </ul>
              </li>
            </ul>
          </div>

          <div>
            <ul className="sideright">
              <ul className="right-nav">
                <li>
                  <a class="active" href="/">
                    MY MEDICATION
                  </a>
                </li>

                <a class="active" href="#news">
                  MY PRESCRIPTION
                </a>
                <a class="active" href="#contact">
                  MY TEST REPORTS
                </a>

                <a href="/">APPOINTMENTS</a>
              </ul>
            </ul>
          </div>
        </body>
      </div>
    );
  }
}
export default Docdash;
