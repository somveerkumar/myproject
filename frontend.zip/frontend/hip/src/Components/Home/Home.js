import React, { Component } from "react";
import "./homeStyle.css";
import "tachyons";
import { Link } from "react-router-dom";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Getaction } from "../Redux/Actions/Getaction";

class Home extends Component {
  constructor(props) {
    super(props);
    console.log(this.props.post);
  }
  static propTypes = [PropTypes.array];

  componentDidMount() {
    this.props.Getaction();
  }
  render() {
    return (
      <div id="body">
        <div id="header">
          <h3>Welcome to Blockchain Solutions</h3>
        </div>
        <div id="navigationbar">
          <link
            rel="stylesheet"
            href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
          />
          <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
          />
          <ul>
            <button href="/" className="buttonhome">
              <i className="fa fa-home"></i> Home
            </button>

            <button href="/" className="buttonsearch">
              <i className="fa fa-search"></i>Search
            </button>

            <button href="/" className="buttongmail">
              <i className="fa fa-envelope"></i>Gmail
            </button>

            <button href="/" className="buttoncloud">
              <i className="glyphicon glyphicon-cloud"></i> Cloud
            </button>

            <button href="/" className="buttonrefresh">
              <i className="fa fa-refresh"></i>Refresh
            </button>

            <Link to="Login" alt="">
              <button type="button" className="buttonlogin">
                {" "}
                LOGIN{" "}
              </button>
            </Link>

            <button className="buttonbar">
              <i className="fa fa-bars"></i>
            </button>
          </ul>
        </div>
        <div className="imgbar">
          <img src="/img/blockchainimg.jpg" alt=""></img>
        </div>
        <div className="sideright">
          <h2>Latest Updates</h2>
          <p>Gender: {this.props.post.gender}</p>
          <p>Email:{this.props.post.email}</p>
          <p>Phone:{this.props.post.phone}</p>
          <p>{this.props.post.gender}</p>
          <p>{this.props.post.gender}</p>
          <p>{this.props.post.gender}</p>
        </div>
        <div className="sideright">
          <h2>Current Events</h2>
          <p>Products based </p>
          <p>Services based</p>
          <p>Sashwat pandey</p>
          <p>Anurag pandey</p>
          <p>Rama sankar</p>
          <p>Maria</p>
        </div>

        <div className="main">
          <h1 id="h1">BLOCKTRACK-FIDUS SOLUTIONS</h1>
          <p>
            Prabhu Rajagopal is a Professor in the Department of Mechanical
            Engineering and an Associate of the Centre for Nondestructive
            Evaluation at IIT Madras (IITM). Af ter graduating from IIT Madras
            in 2003 with a Dual Degree Masters in Mechanical Engineering with
            specialization in Intelligent Manufacturing, he obtained his PhD in
            Ultrasonic NDE from Imperial College London, UK in 2007. As a
            post-doctoral researcher, he developed advanced computational tools
            for inspection
          </p>
        </div>
        <div className="main">
          <h1 id="h1">BLOCKTRACK-WELCOMES YOU</h1>
          <p>
            Prabhu Rajagopal is a Professor in the Department of Mechanical
            Engineering and an Associate of the Centre for Nondestructive
            Evaluation at IIT Madras (IITM). Af ter graduating from IIT Madras
            in 2003 with a Dual Degree Masters in Mechanical Engineering with
            specialization in Intelligent Manufacturing, he obtained his PhD in
            Ultrasonic NDE from Imperial College London, UK in 2007. As a
            post-doctoral researcher, he developed advanced computational tools
            for inspection
          </p>
        </div>

        <div id="footer">
          <ul>
            <li>
              <a href="/">About</a>
            </li>
            <li>
              <a href="/">Career</a>
            </li>
            <li>
              <a href="/">History</a>
            </li>
            <li>
              <a href="/">Contact Us</a>
            </li>
          </ul>
          &copy;2020 fidus.com. All Rights are Reserved.
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  post: state.post.post,
});

// const mapDispatchToProps = (dispatch) => {
//   return { Getaction: () => dispatch(Getaction(Item)) };
// };

export default connect(mapStateToProps, { Getaction })(Home);
