import React, { Component } from "react";

class Familyinfo extends Component {
  constructor() {
    super();

    this.state = {
      check1: false,
      check2: false,
      check3: false,
      check4: false,
      check5: false,
      check6: false,
      Diabetes: false,
      Heart: false,
      Cancer: false,
      Gendef: false,
      cond: "",
    };

    this.onCheck = this.onCheck.bind(this);
    console.log(this.state);
  }

  medCon = (event) => {
    this.setState({ cond: event.target.value });
  };

  onCheck = (event) => {
    this.setState({ [event.target.name]: event.target.checked });
  };

  back = (event) => {
    event.preventDefault();
    this.props.prevStep();
  };

  submit = (event) => {
    event.preventDefault();
    this.props.handleSubmit();
  };

  render() {
    const { cond } = this.state;
    return (
      <form className="tc dib ba  ma4 bg-light-white ba form">
        <div style={{ marginLeft: "40px" }}>
          <div>
            <h2>Patient's Medical History</h2>
          </div>
          <div>
            <p>
              <h3>Check if you've received any of the below vaccinations:</h3>
            </p>
            <input
              type="checkbox"
              name="check1"
              checked={this.state.check1}
              onChange={this.onCheck}
              style={{ marginLeft: "40px" }}
            />
            BCG <br />
            <input
              type="checkbox"
              name="check2"
              checked={this.state.check2}
              onChange={this.onCheck}
              style={{ marginLeft: "40px" }}
            />{" "}
            Cholera <br />
            <input
              type="checkbox"
              name="check3"
              checked={this.state.check3}
              onChange={this.onCheck}
              style={{ marginLeft: "40px" }}
            />{" "}
            Hepatitis A <br />
            <input
              type="checkbox"
              name="check4"
              checked={this.state.check4}
              onChange={this.onCheck}
              style={{ marginLeft: "40px" }}
            />{" "}
            Hepatitis B <br />
            <input
              type="checkbox"
              name="check5"
              checked={this.state.check5}
              onChange={this.onCheck}
              style={{ marginLeft: "40px" }}
            />{" "}
            Measles <br />
            <input
              type="checkbox"
              name="check6"
              checked={this.state.check6}
              onChange={this.onCheck}
              style={{ marginLeft: "40px" }}
            />{" "}
            Chickenpox <br />
          </div>
          <div>
            <p>
              <h3>Check if you have family history in any of the following:</h3>
            </p>
            <input
              type="checkbox"
              name="Diabetes"
              checked={this.state.Diabetes}
              onChange={this.onCheck}
              style={{ marginLeft: "40px" }}
            />{" "}
            Diabetes <br />
            <input
              type="checkbox"
              name="Heart"
              checked={this.state.Heart}
              onChange={this.onCheck}
              style={{ marginLeft: "40px" }}
            />{" "}
            Heart related <br />
            <input
              type="checkbox"
              name="Cancer"
              checked={this.state.Cancer}
              onChange={this.onCheck}
              style={{ marginLeft: "40px" }}
            />{" "}
            Cancer <br />
            <input
              type="checkbox"
              name="Gendef"
              checked={this.state.Gendef}
              onChange={this.onCheck}
              style={{ marginLeft: "40px" }}
            />{" "}
            Genetic Deformity <br />
            <p></p>
          </div>
          <div>
            <label>
              <h3>Medical Condition: </h3>
            </label>
            <input
              type="text"
              style={{ marginLeft: "40px" }}
              value={cond}
              placeholder="Any other medical condition"
              onChange={this.medCon}
            />
            {/* <textarea value={surg} onChange={this.handlesurg}></textarea> */}
            <p></p>
          </div>
          <button
            className="Back"
            style={{ marginLeft: "40px" }}
            onClick={this.back}
          >
            « Back
          </button>
          <button
            className="Submit"
            style={{ marginLeft: "40px" }}
            onClick={this.submit}
          >
            Submit
          </button>

          {/* <button type='submit'>Submit</button> */}
        </div>
      </form>
    );
  }
}

export default Familyinfo;
