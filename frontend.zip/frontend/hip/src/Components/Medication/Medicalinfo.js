import React, { Component } from "react";
import Personalinfo from "./Personalinfo";
import Familyinfo from "./Familyinfo";
import "tachyons";
import "./medicalinfo.css";
class Medicalinfo extends Component {
  constructor(props) {
    super(props);
    this.state = { step: 1 };
    console.log("hello i am here");
  }

  nextStep = () => {
    const { step } = this.state;
    this.setState({ step: step + 1 });
  };

  prevStep = () => {
    const { step } = this.state;
    this.setState({ step: step - 1 });
  };

  handleSubmit = (event) => {
    alert(` Details successfully recorded `);
  };

  showStep = () => {
    const { step } = this.state;
    if (step === 1) return <Personalinfo nextStep={this.nextStep} />;
    if (step === 2)
      return (
        <Familyinfo prevStep={this.prevStep} handleSubmit={this.handleSubmit} />
      );
  };

  render() {
    const { step } = this.state;
    return (
      <div style={{ backgroundColor: "black", opacity: "01" }}>
        <header className="header bg-light-blue">
          {" "}
          MY MEDICATION
          <h2>Step {step} of 2</h2>
        </header>
        {this.showStep()}
      </div>
    );
  }
}

export default Medicalinfo;
