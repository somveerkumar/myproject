import React, { Component } from "react";
import "./personalinfo.css";
class Personalinfo extends Component {
  constructor(props) {
    super(props);

    this.state = {
      bloodGroup: "A+",
      hivstatus: "Unknown",
      comments: "",
      check1: false,
      check2: false,
      check3: false,
      check4: false,
      check5: false,
      check6: false,
      surg: "",
    };

    this.onCheck = this.onCheck.bind(this);
    console.log(this.state);
  }

  handlehivStatus = (event) => {
    this.setState({
      hivstatus: event.target.value,
    });
  };

  handlebloodGroup = (event) => {
    this.setState({
      bloodGroup: event.target.value,
    });
  };

  handlecomments = (event) => {
    this.setState({
      comments: event.target.value,
    });
  };

  handlephydis = (event) => {
    this.setState({
      phydis: event.target.value,
    });
  };

  handlesurg = (event) => {
    this.setState({
      surg: event.target.value,
    });
  };

  onCheck = (event) => {
    this.setState({
      [event.target.name]: event.target.checked,
    });
  };

  handlesubmit = (event) => {
    event.preventDefault();
    alert(` Details successfully recorded `);
  };

  continue = (event) => {
    event.preventDefault();
    this.props.nextStep();
  };

  render() {
    const { hivstatus, bloodGroup, comments, phydis, surg } = this.state;
    return (
      <form className="tc dib ba  ma4 bg-light-white ba  form">
        <div style={{ marginLeft: "40px" }}>
          <div>
            <div>
              <h2>Patient's Medical History</h2> <p></p>
              <label>
                <h4>Blood Group: </h4>
              </label>
              <select value={bloodGroup} onChange={this.handlebloodGroup}>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
              </select>
            </div>

            <label>
              <h4>HIV Status:</h4>
            </label>
            <select value={hivstatus} onChange={this.handlehivStatus}>
              <option value="Positive">Positive</option>
              <option value="Negative">Negative</option>
              <option value="Unknown">Unknown</option>
            </select>
            <p></p>
          </div>

          <div>
            <label>
              <h4>Allergies if any: </h4>
            </label>
            <input
              type="text"
              value={comments}
              placeholder="Enter if you have any allergies"
              onChange={this.handlecomments}
            />
            {/* <textarea value={comments} onChange={this.handlecomments}></textarea> */}
            <p></p>
          </div>

          <div>
            <label>
              <h4>Physical disability:</h4>
            </label>
            <input
              type="text"
              value={phydis}
              placeholder="Enter if any physical disability"
              onChange={this.handlephydis}
            />
            {/* <textarea value={phydis} onChange={this.handlephydis}></textarea> */}
            <p></p>
          </div>

          <div>
            <label>
              <h4>Medical procedure: </h4>
            </label>
            <input
              type="text"
              value={surg}
              placeholder="Any surgeries in past"
              onChange={this.handlesurg}
            />
            {/* <textarea value={surg} onChange={this.handlesurg}></textarea> */}
            <p></p>
          </div>

          <button className="Next" onClick={this.continue}>
            Next »
          </button>

          {/* <button type='submit'>Submit</button> */}
        </div>
      </form>
    );
  }
}

export default Personalinfo;
