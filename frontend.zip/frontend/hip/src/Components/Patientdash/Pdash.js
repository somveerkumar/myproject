/** @format */
import React, { Component } from "react";
import "./pdash.css";
import "tachyons";
import Login from "../Account/Login";
import get from "../../axiosapi";
import { withRouter } from "react-router-dom";
import { Link } from "react-router-dom";
import { Getaction } from "../Redux/Actions/Getaction";
import { connect } from "react-redux";

class Pdash extends Component {
  constructor(props) {
    super(props);
    console.log(this.props);
    const state = { token: localStorage.getItem("token") };
    console.log("in the pdash" + state.token);
  }

  async getResponse() {
    const AuthString = Login.handleSubmit;
    console.log("Token:" + AuthString);
    try {
      let response = get(URL, { headers: { Authorization: AuthString } });
      console.log("Response Data is:" + response.data["access"]);
      return JSON.stringify(response.data);
    } catch (error) {
      throw error;
    }
  }
  componentDidMount() {
    this.props.Getaction();
  }

  render() {
    return (
      <div>
        <div id="header">
          <h3>Patient Deshboard </h3>
        </div>
        <div className="sideleft">
          <ul className="right-nav">
            <img id="profile" src="/img/profile.png" alt="" />

            <Link to="profile">
              <h2> {this.props.post.gender}</h2>
            </Link>
            <a className="active" href="/">
              ACCOUNT
            </a>
            <a className="active" href="/MEDICAL HISTORY">
              HISTORY
            </a>
            <a className="active" href="MESSAGES">
              MESSAGES
            </a>
            <a className="active" href="MOST RECENT">
              MOST RECENT
            </a>
            <a className="active" href="LANGUAGE">
              LANGUAGE
            </a>
            <a className="active" href="FEEDBACK">
              FEEDBACK
            </a>
            <a className="active" href="SETTING">
              SETTING
            </a>
            <a className="active" href="HELP">
              HELP
            </a>
            <a className="active" href="ABOUT">
              ABOUT
            </a>
          </ul>
        </div>
        <div>
          <ul className="sideright">
            <ul className="right-nav">
              <li>
                <Link to="Medicalinfo">
                  <button className="active">MY MEDICATION</button>
                </Link>
              </li>

              <li>
                <Link to="myprscription">
                  <button className="active">MY PRESCRIPTION</button>
                </Link>
              </li>

              <li>
                <Link to="mytestreport">
                  <button className="active">MY TEST REPORTS</button>
                </Link>
              </li>
              <li>
                <Link to="appointment">
                  {" "}
                  <button href="/">APPOINTMENTS</button>
                </Link>
              </li>

              <img id="img" src="/img/gif2.gif" alt="" />
            </ul>
          </ul>
        </div>
        <div id="footer">
          <ul>
            <li>
              <a href="/">About</a>
            </li>
            <li>
              <a href="/">Career</a>
            </li>
            <li>
              <a href="/">History</a>
            </li>
            <li>
              <a href="/">Contact Us</a>
            </li>
          </ul>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  post: state.post.post,
});
export default connect(mapStateToProps, { Getaction })(withRouter(Pdash));
