import axios from "axios";
import { GET_DATA } from "./Types";

export const Getaction = () => (dispatch) => {
  axios
    .get("https://api.randomuser.me")
    .then((res) => {
      dispatch({
        type: GET_DATA,
        payload: res.data.results[0],
      });
      console.log("hiii" + res.status);
      // console.log("hiii" + res.data);
      // console.log("hiii" + res.headers);
      // console.log("hiii" + res.statusText);
      // console.log("hiii" + res.config);
      //console.log("hiii" + res.request);
    })
    .catch((err) => console.log(err));
};
