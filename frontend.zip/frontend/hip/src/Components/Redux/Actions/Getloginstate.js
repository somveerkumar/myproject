import { GET_LOGIN_INFO } from "./Types";

export default function Getloginstate() {
  return {
    type: GET_LOGIN_INFO,
    payload: this.props,
  };
}
