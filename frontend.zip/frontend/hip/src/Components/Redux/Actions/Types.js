export const GET_DATA = "GET_DATA";
export const GET_LOGIN_INFO = "GET_LOGIN_INFO";
