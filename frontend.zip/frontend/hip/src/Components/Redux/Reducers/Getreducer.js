import { GET_DATA } from "../Actions/Types";
const initialState = {
  post: [],
};

export default function (state = initialState, action) {
  switch (action.type) {
    case GET_DATA:
      return {
        ...state,
        post: action.payload,
      };
    default:
      return state;
  }
}
