import { GET_LOGIN_INFO } from "../Actions/Types";

const initialstate = {
  logindata: [],
};
export default function (state = initialstate, action) {
  switch (action.type) {
    case GET_LOGIN_INFO:
      return {
        ...state,
        logindata: action.payload,
      };
    default:
      return state;
  }
}
