import { combineReducers } from "redux";
import Getreducer from "./Getreducer";
import LoginReducer from "./LoginReducer";
const rootReducer = combineReducers({
  post: Getreducer,
  logindata: LoginReducer,
});

export default rootReducer;
