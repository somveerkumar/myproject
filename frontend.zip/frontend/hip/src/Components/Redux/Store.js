import { createStore, applyMiddleware } from "redux";
import thunk from "redux-thunk";
import { composeWithDevTools } from "redux-devtools-extension";
import rootReducer from "./Reducers/Rootreducer";

const post = {};

const middleware = [thunk];
const store = createStore(
  rootReducer,
  post,
  composeWithDevTools(applyMiddleware(...middleware))
);

export default store;
